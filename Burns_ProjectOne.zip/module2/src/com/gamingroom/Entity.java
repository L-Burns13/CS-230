package com.gamingroom;

public class Entity {

	protected long id;
	protected String name;

	protected Entity() {
	}

	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}

	public long getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String toString() {
		return "Entity [id=" + this.id + ", name=" + this.name + "]";
	}
}
