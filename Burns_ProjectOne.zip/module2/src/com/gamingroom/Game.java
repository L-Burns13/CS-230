package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A class to represent a game, which contains multiple teams.
 */

public class Game extends Entity {
	
	//Instance list of teams in this game
    private List<Team> teams = new ArrayList<>();
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	//Adds a team to the game
    public Team addTeam(String name) {
        for (Team team : teams) {
            if (team.getName().equalsIgnoreCase(name)) {
                return team; // Return existing team
            }
        }

        Team newTeam = new Team(GameService.getInstance().getNextTeamId(), name);
        teams.add(newTeam);
        return newTeam;
    }	

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
